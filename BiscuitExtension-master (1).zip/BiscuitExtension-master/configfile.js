
var web = "https://rol.redhat.com/rol/app/classes"